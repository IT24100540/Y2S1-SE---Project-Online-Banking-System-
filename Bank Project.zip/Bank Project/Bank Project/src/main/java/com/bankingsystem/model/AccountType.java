// src/main/java/com/bankingsystem/model/AccountType.java
package com.bankingsystem.model;

public enum AccountType {
    SAVINGS, CURRENT
}