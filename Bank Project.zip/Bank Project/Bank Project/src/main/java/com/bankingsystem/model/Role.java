// src/main/java/com/bankingsystem/model/Role.java
package com.bankingsystem.model;

public enum Role {
    CUSTOMER, STAFF, ADMIN
}