package com.bankingsystem.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;

@Entity
public class FixDeposit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Fix Deposit type is required")
    private String fixDepositType;

    @Positive(message = "Amount must be positive")
    private double amount;

    @Positive(message = "Duration must be positive")
    private int duration;

    @Enumerated(EnumType.STRING)
    private FixDepositStatus status;

    @ManyToOne
    private User applicant;

    @ManyToOne
    private User reviewer;

    @ManyToOne
    private User approver;

    // Default constructor
    public FixDeposit() {
    }

    // Constructor with all fields
    public FixDeposit(Long id, String fixDepositType, double amount, int duration,
            FixDepositStatus status, User applicant, User reviewer, User approver) {
        this.id = id;
        this.fixDepositType = fixDepositType;
        this.amount = amount;
        this.duration = duration;
        this.status = status;
        this.applicant = applicant;
        this.reviewer = reviewer;
        this.approver = approver;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFixDepositType() {
        return fixDepositType;
    }

    public void setFixDepositType(String fixDepositType) {
        this.fixDepositType = fixDepositType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public FixDepositStatus getStatus() {
        return status;
    }

    public void setStatus(FixDepositStatus status) {
        this.status = status;
    }

    public User getApplicant() {
        return applicant;
    }

    public void setApplicant(User applicant) {
        this.applicant = applicant;
    }

    public User getReviewer() {
        return reviewer;
    }

    public void setReviewer(User reviewer) {
        this.reviewer = reviewer;
    }

    public User getApprover() {
        return approver;
    }

    public void setApprover(User approver) {
        this.approver = approver;
    }
}