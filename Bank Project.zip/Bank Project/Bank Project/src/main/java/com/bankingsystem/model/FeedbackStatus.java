// src/main/java/com/bankingsystem/model/FeedbackStatus.java
package com.bankingsystem.model;

public enum FeedbackStatus {
    OPEN, IN_PROGRESS, RESOLVED
}