package com.bankingsystem.model;

public enum FixDepositStatus {
    PENDING, IN_REVIEW, APPROVED, REJECTED
}