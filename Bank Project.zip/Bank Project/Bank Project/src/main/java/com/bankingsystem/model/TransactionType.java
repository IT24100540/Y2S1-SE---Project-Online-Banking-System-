// src/main/java/com/bankingsystem/model/TransactionType.java
package com.bankingsystem.model;

public enum TransactionType {
    DEPOSIT, WITHDRAWAL, TRANSFER
}