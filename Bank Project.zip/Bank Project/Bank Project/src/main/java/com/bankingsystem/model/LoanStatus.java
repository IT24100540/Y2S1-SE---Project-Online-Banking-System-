// src/main/java/com/bankingsystem/model/LoanStatus.java
package com.bankingsystem.model;

public enum LoanStatus {
    PENDING, IN_REVIEW, APPROVED, REJECTED
}